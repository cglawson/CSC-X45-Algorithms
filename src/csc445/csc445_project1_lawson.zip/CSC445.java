/*
 *   Caleb Lawson
 *   CSC 445
 *   Completed 1/17/2015
 *
 *   This class makes it easy for me to launch project classes in my IDE and keep
 *   them all in the same GitHub repository.
 */
package csc445;

public class CSC445 {

    public static void main(String[] args) {
        Project1 project1 = new Project1();
        //NewClass nc = new NewClass();
    }

}
